  jQuery(function (){
      jQuery("#applygnfn").popover();
});

jQuery(function (){
      jQuery("#applyfnln").popover();
});

jQuery(function (){
    jQuery("#applydob").popover();
});

jQuery(function (){
    jQuery("#applycob").popover();
});
jQuery(function (){
    jQuery("#prsnlid").popover();
	jQuery("#nidn").popover();
});

jQuery(function (){
    jQuery("#applywcac").popover();
});

jQuery(function (){
    jQuery("#applyiwc").popover();
});

jQuery(function (){
    jQuery("#applyea").popover();
});

jQuery(function (){
    jQuery("#applycea").popover();
});

jQuery(function (){
    jQuery("#applyaea").popover();
});

jQuery(function (){
    jQuery("#applyctn").popover();
});


jQuery(function (){
    jQuery("#applyaliasfirst").popover();
});


jQuery(function (){
    jQuery("#applyaliaslast").popover();
});


jQuery(function (){
    jQuery("#applycityob").popover();
});

jQuery(function (){
    jQuery("#applyfather").popover();
});

jQuery(function (){
    jQuery("#applygivenfather").popover();
});

jQuery(function (){
    jQuery("#applymother").popover();
});

jQuery(function (){
    jQuery("#applygivenmother").popover();
});

jQuery(function (){
    jQuery("#nidn").popover();
});

jQuery(function (){
    jQuery("#").popover();
});
jQuery(function (){
    jQuery("#").popover();
});

jQuery(function (){
    jQuery("#").popover();
});



/*-------------------2222222222222-----------------*/

jQuery(function (){
    jQuery("#applywciyp").popover();
});

jQuery(function (){
    jQuery("#applyissue").popover();
});

jQuery(function (){
    jQuery("#applywwypi").popover();
});

jQuery(function (){
    jQuery("#applywdype").popover();
});

jQuery(function (){
    jQuery("#applywiypn").popover();
});
