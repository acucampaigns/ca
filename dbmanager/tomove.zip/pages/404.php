<?php
	
if(!defined('DIR_ACCESS'))	
	die('404!');