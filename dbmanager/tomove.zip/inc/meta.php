<?php
return array(
	
	'home' => array(
	
		'title' 		=> 'eTA Visa Canada - Application',
		'keywords' 		=> '',
		'description' 	=> ''
	
	)	
	
);