		<!--footer Start here-->
		<div id="footer">
			
			<div class="container">
			
				<div class="row">
				
					<div class="span12 text-center">
					
						<div class="text-center">
						
							<ul>
								
								<li class="first here"><a href="index.html" title="">Home</a></li>
							   
								<li><a href="<?= __BASE_URL; ?>/apply-for-canada-eta/index.html" title="">eTA Application</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/canada-eta-requirements/index.html" title="">eTA Requirements</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/what-is-canada-eta/index.html" title="" >eTA FAQs</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/canada-eta-service/index.html" title="">eTA Services</a></li>
							   
								<li><a href="<?= __BASE_URL; ?>/costs/index.html" title="">Costs</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/contacts/index.html" title="">Contacts</a></li>
						   
							</ul>
							
						</div>
						
						<div class="text-align">
						
							<ul>
								
								<li><a href="<?= __BASE_URL; ?>/information/terms-and-conditions/index.html">Terms and Conditions</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/information/privacy-policy/index.html">Privacy Policy</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/information/disclaimer/index.html">Disclaimer</a></li>
								
								<li><a href="<?= __BASE_URL; ?>/information/refund-policy/index.html">Refund Policy</a></li>
						  
							</ul>
							
							<br />
							
							<hr>
							
							<p>
								
								<small>canada-etavisa.info is a private company and is not affiliated with any government agency. We assist foreign travellers needing proper documentation to enter Canada . Our service fees are $100 US Dollars and include the Canadian Government fee of CA$7. You may choose to engage our services or visit cic Internet sites and make your request to travel to Canada for a lesser fee. The Government site can be accessed at <a href="http://www.cic.gc.ca/">www.cic.gc.ca</a></small>
							
							</p>
							
							<br />
							
							<br />					
							
							<p>
								&copy;  <?= date('Y');?> - <span class="lowercase">canada-etavisa.info</span></br>
								All rights reserved</br>
								
							</p>
							
						</div>

					</div>
					
				</div>
				
			</div>
			
		</div>
		<!--footer Stop here-->
		<?php get_footer_scripts($extra); ?>
	
	</body>
	
</html>