		<!-- Piwik 
		<script type="text/javascript">
			
			var _paq = _paq || [];
			_paq.push(['trackPageView']);
			_paq.push(['enableLinkTracking']);
			(function () {
				var u = "http://ryanlion.piwikpro.com/";
				_paq.push(['setTrackerUrl', u + 'piwik.php']);
				_paq.push(['setSiteId', 7]);
				var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
				g.type = 'text/javascript'; g.async = true; g.defer = true; g.src = u + 'piwik.js'; s.parentNode.insertBefore(g, s);
			})();
		</script>

		<noscript>

			<p><img src="http://ryanlion.piwikpro.com/piwik.php?idsite=7" style="border: 0;" alt="" /></p>

		</noscript>
		End Piwik Code -->
		<script type="text/javascript" src="<?= __BASE_URL; ?>/assets/components/minifyx/cache/scripts_0976d4171e.js"></script>