<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Contacts system login</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- link rel="shortcut icon" href="favicon.png" / -->
  <link rel="stylesheet" href="css/main.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body>
    <div class="container">
        <div class="row frm-div frm-div2" id="frm-login">
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-danger frm-hidden login-alert">
                    <button type="button" class="close">&times;</button>
                    Invalid username or password. Please, check if you entered your credentials correct or <span class="frm-toggle">register new account</span>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">User login</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="form-login">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Login" name="login" type="text" required autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" required value="">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button id="login-btn" type="button" class="btn btn-success btn-block">Login</button>
                                <div class="row">
                                    <div class="col-xs-6 pull-left">
                                        <span class="frm-toggle">New Member?</span>
                                    </div>
                                    <div class="col-xs-6">
                                        <span class="forgot-toggle pull-right">Forgot password?</span>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row frm-div frm-hidden" id="frm-register">
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-success frm-hidden register-alert-ok">
                    <button type="button" class="close">&times;</button>
                    Your account is successfully created. Now you can <span class="frm-toggle">log in</span>.
                </div>
                <div class="alert alert-danger frm-hidden register-alert-fail">
                    <button type="button" class="close">&times;</button>
                    <p></p>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Register new user</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="form-register">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="First name" name="firstname" type="text" required autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Last name" name="lastname" type="text" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Login" name="login" type="text" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" id="frm-reg-pass" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password Verify" name="passwordVerify" type="password" value="" id="frm-reg-verify" title="Password missmatch" required>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button id="register-btn" type="button" class="btn btn-success btn-block">Create user</button>
                                <p>Already have account? <span class="frm-toggle">Sign in</span></p>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row frm-hidden frm-div2" id="frm-forgot">
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-success frm-hidden forgot-alert-ok">
                    <button type="button" class="close">&times;</button>
                    We send you a message with link for password reset
                </div>
                <div class="alert alert-danger frm-hidden forgot-alert-fail">
                    <button type="button" class="close">&times;</button>
                    Can't find user with this email
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Enter your email for password restore</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="form-forgot">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" required>
                                </div>
                                <button id="forgot-btn" type="button" class="btn btn-success btn-block">Send link</button>
                                <p><span class="forgot-toggle">Back to login</span></p>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="js/index.js"></script>
</body>