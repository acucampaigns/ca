<?php
	
	
	
// $to 		= 'contact@eta-australia.com.au';			
// $email 		= 'bovoom@gmail.com';	
// $subject 	= 'Application Form, From:'.$email;
// $headers 	= "MIME-Version: 1.0" . "\r\n";
// $headers   .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// // Additional headers
// $headers .= 'From:eta-australia.com.au<info@eta-australia.com.au>' . "\r\n";
	
// mail($to, $subject, "<h1>Hello World!</h1>", $headers);	
	
	
	
?>